
<?php $__env->startSection('content'); ?>
<h5 style="font-weight: bold;">Thêm danh mục</h5>
 <div class="container">
     <div class="row">
         <div class="col-sm-10">
         <form action="<?php echo e(route('category.store')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="categoryname" style="font-weight: bold">Danh mục sản phẩm</label>
            <input type="text" name="categoryName" id="categoryName" class="form-control">
          
          <?php if($errors->has('categoryName')): ?>
          <p><?php echo e($errors->first('categoryName')); ?></p>
              
          <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="description" style="font-weight: bold">Bài viết danh mục</label>
            <textarea name="cate_description" class="form-control summernote" id="summernote"></textarea>
        </div>
        <div class="form-group">
            <input type="submit" value="Thêm danh mục" class="btn btn-info btn-sm">

        </div>
        </form>
         </div>

     </div>
 </div>
 <script>
    $(document).ready(function(){
   
   $('.summernote').summernote({
       height: 240,
       minHeight: null,
       maxHeight: null,
       focus: false
   });
   
   });
     </script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\weblinhkien\resources\views/category/create.blade.php ENDPATH**/ ?>