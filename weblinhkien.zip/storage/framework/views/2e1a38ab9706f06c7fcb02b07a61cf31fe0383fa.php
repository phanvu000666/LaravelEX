
<?php $__env->startSection('content'); ?>
<div class="container jumbotron   border border-success">
    <h2>Danh mục sản phẩm quản lý</h2>
           
    <table class="table">
      <thead class="bg-danger text-white"> 
        <tr>
          <th>Tên sản phẩm</th>
            <th>hình ảnh</th>
         <th>Giá sản phẩm</th>
        <th>Giảm giá</th>
       <th>Thao tác</th>
    
        </tr>
      </thead>
      <tbody>
       <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
        <td>
           <?php echo e($product->productName); ?> 
        <td>
             <div class="product-image-thumb" ><img src="../public/upload/<?php echo e($product->productImage); ?>" alt="Product Image"></div>
        </td>
        <td>
          <?php echo e(number_format($product->listPrice)); ?>đ
        </td>
        <td><?php echo e($product->discountPercent); ?>%</td>
        <td> 
            <a class="button btn btn-success" href="<?php echo e(route('product.edit',$product->productID)); ?>"><i class="fas fa-tools"></i>  Sửa</a>
            <form class="d-inline-block " action="<?php echo e(route('product.destroy',$product->productID)); ?>" method="post" >
              <?php echo e(csrf_field()); ?>

              <?php echo method_field('DELETE'); ?>
              
              
              
              
              
              <input type="submit" value="Xóa" class="button btn btn-danger">
              </form>
          
          </td>
      </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       


      </tbody>
    </table>
    <div class="d-flex justify-content-center"><?php echo e($products->links()); ?></div>
    <p class="d-flex justify-content-end">
        <a class="btn btn-info btn-sm fa fa-plus" href="<?php echo e(route('product.create')); ?>">Thêm Sản phẩm</a>
    </p>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\weblinhkien\resources\views/product/index.blade.php ENDPATH**/ ?>