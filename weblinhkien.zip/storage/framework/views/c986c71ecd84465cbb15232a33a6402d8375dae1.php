<footer class="main-footer">
    <strong></strong>
    
    <div class="float-right d-none d-sm-inline-block">
     
    </div>
  </footer><?php /**PATH C:\wamp64\www\weblinhkien\resources\views/layout/admin/footer.blade.php ENDPATH**/ ?>