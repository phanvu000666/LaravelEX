<nav class="navbar navbar-expand-md header-background navbar-dark ">
        
    <a class="navbar-brand" href="#">
     
        <i class="fas fa-home"></i>
        <h5>Home</h5>

    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <form class="form-inline" action="<?php echo e(route('home.find')); ?>" method="post">
      <?php echo e(csrf_field()); ?>

        <input class="form-control mr-sm-2" type="search" name="keywords" placeholder="Nhập tên sản phẩm cần tìm">
        <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
      </form>
      <div class=" navbar-collapse justify-content-end inner-header" id="collapsibleNavbar">
      <ul class="navbar-nav" style="float: right;">
            <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item cart-icon">
                
                <a class="nav-link btn btn-success" href="<?php echo e(url('List-Carts')); ?>"><i class="fas fa-cart-arrow-down"></i> <b>Giỏ hàng</b>
                    <?php if(Session::has("Cart") != null): ?>
                    <span style="width: 25px;" id="total-quanty-show" class="badge badge-success ml-3"><?php echo e(Session::get("Cart")->totalQuanty); ?></span>
                    <?php else: ?>
                    <span style="width: 25px;" id="total-quanty-show" class="badge badge-success ml-3">0</span>
                    <?php endif; ?>
                </a>
            <div class="cart-hover">
                <div id="change-item-cart">
                    <?php if(Session::has("Cart") != null): ?>
                    <div class="select-items">
                      <table>
                          <tbody>
                             <?php $__currentLoopData = Session::get('Cart')->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td class="si-pic"><img src="public/upload/<?php echo e($item['productInfo']->productImage); ?>" style="vertical-align: middle;  width:80px;margin-right: 30px" alt=""></td>
                                  <td class="si-text">
                                      <div class="product-selected">
                                          <b><?php echo e(number_format($item['productInfo']->listPrice)); ?>₫ x <?php echo e($item['quanty']); ?></b>
                                          <h6><?php echo e($item['productInfo']->productName); ?></h6>
                                      </div>
                                  </td>
                                  <td class="si-close">
                                  <h4><a class="" data-id="<?php echo e($item['productInfo']->productID); ?>" role="button"><i class="far fa-times"></i></a></h4>  
                                  </td>
                              </tr>
                                           
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>
                    </div>
                    <div class="select-total">
                      <h6>TỔNG TIỀN:</h6>
                      <h5><?php echo e(number_format(Session::get('Cart')->totalPrice)); ?>₫</h5>
                               </div>
                               <div class="select-button">
                                <a href="<?php echo e(url('List-Carts')); ?>" class="primary-btn view-card"> <b>XEM GIỎ HÀNG</b> </a>
                                <a href="#" class="primary-btn checkout-btn"><b>THANH TOÁN</b></a>
                            </div>
                            <?php else: ?> 
                            <h4 style="color: #4A235A;">Vui lòng thêm sản phẩm</h4>
                            <?php endif; ?>
                               </div>
                                 
                                
                             </div>
              
            </li> 
        <li class="nav-item">
          <a class="nav-link btn btn-info" href="<?php echo e(route('login')); ?>" ><b>Đăng nhập</b></a>
        </li>
         <?php if(Route::has('register')): ?>
        <li class="nav-item">
          <a class="nav-link btn btn-info" href="<?php echo e(route('register')); ?>"><b>Đăng ký</b></a>
        </li>
        
        <?php endif; ?>

        
        <?php else: ?> 
        <li class="nav-item cart-icon">
            
            <a class="nav-link btn btn-success" href="<?php echo e(url('List-Carts')); ?>"><i class="fas fa-cart-arrow-down"></i> <b>Giỏ hàng</b></span>
              <?php if(Session::has("Cart") != null): ?>
                    <span style="width: 25px;" id="total-quanty-show" class="badge badge-success ml-3"><?php echo e(Session::get("Cart")->totalQuanty); ?></span>
                    <?php else: ?>
                    <span style="width: 25px;" id="total-quanty-show" class="badge badge-success ml-3">0</span>
                    <?php endif; ?>
            
            </a>
            <div class="cart-hover">
                <div id="change-item-cart">
                    <?php if(Session::has("Cart") != null): ?>
                    <div class="select-items">
                      <table>
                          <tbody>
                             <?php $__currentLoopData = Session::get('Cart')->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td class="si-pic"><img src="public/upload/<?php echo e($item['productInfo']->productImage); ?>" style="vertical-align: middle;  width:80px;margin-right: 30px" alt=""></td>
                                  <td class="si-text">
                                      <div class="product-selected">
                                          <b><?php echo e(number_format($item['productInfo']->listPrice)); ?>₫ x <?php echo e($item['quanty']); ?></b>
                                          <h6><?php echo e($item['productInfo']->productName); ?></h6>
                                      </div>
                                  </td>
                                  <td class="si-close">
                                    <h4><a class="" data-id="<?php echo e($item['productInfo']->productID); ?>" role="button"><i class="far fa-times"></i></a></h4>
                                  </td>
                              </tr>
                                           
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>
                    </div>
                    <div class="select-total">
                      <h6>TỔNG TIỀN:</h6>
                      <h5><?php echo e(number_format(Session::get('Cart')->totalPrice)); ?>₫</h5>
                               </div>
                               <div class="select-button">
                                <a href="<?php echo e(url('List-Carts')); ?>" class="primary-btn view-card"> <b>XEM GIỎ HÀNG</b> </a>
                                <a href="#" class="primary-btn checkout-btn"><b>THANH TOÁN</b></a>
                            </div>
                               <?php else: ?> 
                               <h4 style="color: #4A235A;">Vui lòng thêm sản phẩm</h4>
                               <?php endif; ?>
                               </div>
                                 
                                
                             </div>
        </li> 
         <li class="nav-item dropdown">
            
          <a class="nav-link btn btn-info dropdown-toggle" id="navbarDropdown" role="button" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
            <i class="fas fa-user"></i> <b><?php echo e(Auth::user()->name); ?></b></a>
               <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">

               <?php if((Auth::check() && Auth::user()->typeuser == 'admin')): ?>
                                <a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">
                                
                                Trang quản trị
                                <i class="fas fa-tasks-alt"></i>
                                </a>
                            <?php endif; ?>
                            <?php if((Auth::check() && Auth::user()->typeuser == 'admin')||(Auth::check() && Auth::user()->typeuser == 'user')): ?>

                            <a class="dropdown-item" href="<?php echo e(route('info.index')); ?>">
                                   
                              Thông tin tài khoản
                              <i class="fas fa-user"></i>
                               </a>
                                  <a class="dropdown-item" href="<?php echo e(route('info.show',Auth::user()->id)); ?>">
                                   
                               Chi tiết đặt hàng
                               <i class="fas fa-info-circle"></i>
                                </a>
                            <?php endif; ?>
                               <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                             
                            Đăng xuất
                            <i class="fas fa-sign-out-alt"></i>
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                            
                           </div>
        </li> 
          <?php endif; ?> 
      </ul>
    </div>  
    <br>
    


  </nav>
 
                
          
        
        <div class="container-fluid fixed-top " style="margin-top: 58px; z-index: -1; position: absolute;">
    
          <nav class="navbar hr  ">
           <a class="nav-link btn btn-primary " href="<?php echo e(route('home')); ?>" > <i class="fas fa-home"></i>      Trang chủ</a>
            <a class="nav-link" href="<?php echo e(route('gioithieu')); ?>" ><i class="far fa-hand-point-right"></i>   Giới thiệu</a>
            
                <li class="nav-item dropdown">  
                    <a class="nav-link" href="#" id="navbarDropdown" ><i class="fas fa-bars"></i> Sản phẩm</a>
                    <div class="dropdown-content">
                      <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a class="dropdown-item" href="<?php echo e(route('proshow.show',$item->categoryID)); ?>"><?php echo e($item->categoryName); ?></a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </li>
                <li class="nav-item dropdown">
               <a class="nav-link" href="#" ><i class="fas fa-headset"> </i>    Liên hệ</a>
               <div class="dropdown-content">
                <a class="dropdown-item" href="https://www.messenger.com/t/ngochai.120421">Chat với tư vấn mua hàng</a>
                <h6 class="dropdown-item" href="">CSKH: <a href="" class="btn-outline-info">+0332369993</a>  <i class="fas fa-angle-right"></i> </h6>
               
          
              </div>
              </li>
               <!--  <a class="nav-link" href="<?php echo e(route('build.index')); ?>" style="padding-left: 0px; padding-right: 30px;"><i class="fas fa-tools"></i>   Xây dựng cấu hình</a> -->
              </nav>
              </div> <?php /**PATH C:\wamp64\www\weblinhkien\resources\views/layout/user/header.blade.php ENDPATH**/ ?>