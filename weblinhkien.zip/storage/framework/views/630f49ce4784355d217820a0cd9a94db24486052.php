
<?php $__env->startSection('content'); ?>
<div class="container jumbotron border border-success">
    <h2>Tổng quan</h2>
           
    <table class="table">
      <thead class="bg-primary text-white"> 
        <tr>
          <th>Tên danh mục</th>
          
          <th>Số lượng sản phẩm</th>
        </tr>
      </thead>
      <tbody>
           <?php $__currentLoopData = $quantity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
            <td class="font-weight-bold"><?php echo e($row->categoryName); ?></td>
            
            <td>hiện đang có <?php echo e($row->quantity); ?> Sản phẩm</td>
          </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
 

      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\weblinhkien\resources\views/admin.blade.php ENDPATH**/ ?>