<table class="table">
  <thead>
      <tr></tr>
  </thead>
  <tbody>
   
 
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
     
    
      <td><img src="public/upload/<?php echo e($product->productImage); ?>" style="vertical-align: middle;  width:80px;margin-right: 30px"></td>
      <td>
        <p style="color: #4A235A;"><b><?php echo e($product->productName); ?></b></p>
     </td>
     <td>
      <p><b><?php echo e(number_format( $product->listPrice )); ?>₫</b>
          <p>
  </td>
  <td>

      <a  class="btn btn-danger text-white" onclick="ChoosePro(<?php echo e($product->productID); ?>)">Chọn</a>

  </td>
    </tr>
                                     
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

 </tbody>
   


</table><?php /**PATH C:\xampp\htdocs\weblinhkien\resources\views/buildviewajax.blade.php ENDPATH**/ ?>