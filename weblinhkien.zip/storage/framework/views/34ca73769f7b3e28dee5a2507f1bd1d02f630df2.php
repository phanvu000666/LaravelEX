
<?php $__env->startSection('content'); ?>
<div class="container jumbotron   border border-success">
    <h2>Chi tiết sản phẩm</h2>
           
    <table class="table">
      <thead class="bg-danger text-white"> 
        <tr>
          <th>Tên sản phẩm</th>
            <th>hình ảnh chi tiết</th>
         <th>Tên thương hiệu</th>
        <th>Thời gian bảo hành</th>
       <th>Thao tác</th>
    
        </tr>
      </thead>
      <tbody>
       <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
        <td>
           <?php echo e($product->productName); ?> 
        <td>
             <div class="product-image-thumb" ><img src="../public/upload/<?php echo e($product->productImage1); ?>" alt="Product Image"></div>
             <?php if($product->productImage2 != null): ?>
             <div class="product-image-thumb" ><img src="../public/upload/<?php echo e($product->productImage2); ?>" alt="Product Image"></div>
             <?php endif; ?>
             <?php if($product->productImage3 != null): ?>
             <div class="product-image-thumb" ><img src="../public/upload/<?php echo e($product->productImage3); ?>" alt="Product Image"></div>    
             <?php endif; ?>
             
        </td>
        <td>
            <?php echo e($product->brand); ?> 
        </td>
        <td>  <?php echo e($product->guarantee); ?> Tháng</td>
        <td> 
            <a class="button btn btn-success" href="<?php echo e(route('prodetail.edit',$product->id)); ?>"><i class="fas fa-tools"></i>  Sửa</a>
            <form class="d-inline-block " action="<?php echo e(route('prodetail.destroy',$product->id)); ?>" method="post" >
              <?php echo e(csrf_field()); ?>

              <?php echo method_field('DELETE'); ?>
              
              
              
              
              
              <input type="submit" value="Xóa" class="button btn btn-danger">
              </form>
          
          </td>
      </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       


      </tbody>
    </table>
  
    <p class="d-flex justify-content-end">
        <a class="btn btn-info btn-sm fa fa-plus" href="<?php echo e(route('prodetail.create')); ?>">Thêm chi tiết cho Sản phẩm</a>
    </p>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\weblinhkien\resources\views/productdetail/index.blade.php ENDPATH**/ ?>