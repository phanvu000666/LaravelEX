
<?php $__env->startSection('content'); ?>
<div class="container jumbotron   border border-success">
    <h2>Tìm kiếm sản phẩm</h2>
           
    <table class="table">
      <thead> 
        <tr>
          <th>Tên danh mục</th>
            <th>Tên sản phẩm</th>
            <th>Ảnh sản phẩm</th>
         <th>Giá sản phẩm</th>
       
    
        </tr>
      </thead>
      <tbody>
       <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
        <td><?php echo e($row->categoryName); ?></td>
        <td><?php echo e($row->productName); ?></td>
      
        <td>
             <div class="product-image-thumb" ><img src="../public/upload/<?php echo e($row->productImage); ?>" alt="Product Image"></div>
        </td>
        <td>
          <?php echo e(number_format($row->listPrice)); ?>đ 
        </td>
        
      </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       


      </tbody>
    </table>
    
    <p class="d-flex justify-content-end">
        <a class="btn btn-info btn-sm fa fa-plus" href="<?php echo e(route('product.create')); ?>">Thêm Sản phẩm</a>
    </p>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\weblinhkien\resources\views/product/find.blade.php ENDPATH**/ ?>