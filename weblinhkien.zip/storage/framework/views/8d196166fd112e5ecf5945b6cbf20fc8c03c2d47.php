
<?php $__env->startSection('content'); ?>
<div class="container jumbotron border border-success">
    <h2>Danh sách người dùng hệ thống</h2>
           
    <table class="table">
      <thead class="bg-warning"> 
        <tr class="text-white">
          <th>Tên Người dùng</th>
            <th>Email</th>
         <th>Số điện thoại</th>
        <th>Địa chỉ</th>
       <th>Thao tác</th>
    
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($user->name); ?></td>
          <td><?php echo e($user->email); ?></td>
          <td>
               <?php echo e($user->phonenumber); ?> 
          </td>
          <td>
              <?php echo e($user->address); ?>

          </td>
          
          <td> 
            <a class="button btn btn-success" href="<?php echo e(route('user.edit',$user->id)); ?>"><i class="fas fa-tools"></i>  Sữa</a>
            <form class="d-inline-block " action="<?php echo e(route('user.destroy',$user->id)); ?>" method="post" >
              <?php echo e(csrf_field()); ?>

              <?php echo method_field('DELETE'); ?>
              
              
              
              
             
             <button type="submit" class="button btn btn-danger"> <i class="fas fa-trash-alt"></i> Xóa</button>
              </form>
          
          </td>
        </tr>
       

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
   

  </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\weblinhkien\resources\views/account/index.blade.php ENDPATH**/ ?>