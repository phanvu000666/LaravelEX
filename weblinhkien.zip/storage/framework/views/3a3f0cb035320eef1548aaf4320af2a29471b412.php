
<?php $__env->startSection('content'); ?>
<?php if(Session::has('message')): ?>
  <script type="text/javascript">
     swal({
         title:'Cảm ơn bạn đã đặt hàng!',
         text:"<?php echo e(Session::get('message')); ?>",
         button: "Đồng ý!",
         icon: "success"
     }).then((value) => {
       //location.reload();
     }).catch(swal.noop);
 </script>
 <?php endif; ?>
<div style="height: 90px;"></div>
<div class="container-flud jumbotron border border-info">
 
    <h2  class="mr-5" style="font-weight: bold; color: #4A235A;">Chi tiết đơn hàng của <b><?php echo e(Auth::user()->name); ?></b> </h2>
    <div class="row mt-3">
        <div class="col-sm-2">
    <div class="row">
    <button type="button" class="btn btn-info"> <i class="fas fa-user"></i> Thông tin tài khoản</button>
</div>
<div class="row mt-3">
    <button type="button" class="btn btn-info"> <i class="fas fa-info-circle"></i> Chi tiết đặt hàng</button>
</div>
</div>
        <div class="col-sm-10 bg-white">

            <table class="table table-hover " >
                <thead>
                <tr class="bg-info text-white">
                    <th>STT</th>
                    <th>Tên sản phẩm</th>
                    <th>Số lượng</th>
                    <th>Giá tiền</th>
          
                </tr>
                </thead>
                <tbody>
                   <?php if($bills != null): ?>
                   <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                       <td><?php echo e($key+1); ?></td>
                       <td class="font-weight-bold"><?php echo e($bill->product_name); ?></td>
                       <td><?php echo e($bill->quantily); ?></td>
                       <td><?php echo e(number_format($bill->price)); ?> VNĐ</td>
                   </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php else: ?>
               <tr>
                   <h2 style="color: #4A235A;">Bạn chưa có đơn hàng vui lòng đặt hàng !</h2>
               </tr>
                   <?php endif; ?>
                   
                   <?php if($customer != null): ?>
                   <tr>
                    <td colspan="3" class="font-weight-bold">Trạng thái đơn hàng</td>
                    <td class="font-italic text-success">
                        <?php echo e($customer->bill_status); ?>

                      </td>
                    
                </tr>
                <tr>
                    <td colspan="3" class="font-weight-bold">Hình thức thanh toán</td>
                    <td class="text-info">
                        <b><?php echo e($customer->bill_payment); ?></b>
                      </td>
                    
                </tr>
         
                <tr>
                    <td colspan="3"><b>Tổng tiền</b></td>
                    <td colspan="1"><b class="text-danger"><?php echo e(number_format($customer->bill_total)); ?> VNĐ</b></td>
                </tr>
                
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($customer != null): ?>
   <?php if(( $customer->bill_status == 'Đã giao')): ?>
    <form style="float: right;" class="d-inline-block mt-2 mr-2" action="<?php echo e(route('info.destroy',$customer->id)); ?>" method="post" >
        <?php echo e(csrf_field()); ?>

        <?php echo method_field('DELETE'); ?>
        
        
        
        
       
       <button type="submit" class="button btn btn-danger btn-xl"><i class="fas fa-check-circle"></i> Đã nhận được hàng</button>
        </form>
       
        <?php endif; ?>
        
        <?php endif; ?>
               
    
    </div>
           
</div>
 
   


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\weblinhkien\resources\views/orderdetail.blade.php ENDPATH**/ ?>