<footer class="main-footer">
    <strong>Edit by MrPhuc</strong>
    
    <div class="float-right d-none d-sm-inline-block">
     
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\weblinhkien\resources\views/layout/admin/footer.blade.php ENDPATH**/ ?>