<div class=""><img src="public/upload/<?php echo e($product->productImage); ?>" style="vertical-align: middle;  width:80px;margin-right: 30px"></div>
<div class=""><p style="color: #4A235A;"><b><?php echo e($product->productName); ?></b></p></div>
        <?php /**PATH C:\xampp\htdocs\weblinhkien\resources\views/buildpc.blade.php ENDPATH**/ ?>