
<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="height:110px"></div>
<div class="container bg-white jumbotron " >
  <div class="row p-2" style="border:1px solid rgba(105, 105, 105, 0.26);">
   <div class="list-product-subtitle text-secondary ">
     <h5><?php echo e($category->categoryName); ?></h5></div>
     <div class="spinner-grow text-danger"></div>
   <div class="product-group mt-2">
     <div class="row ">
       <!-- dat foreach -->
       <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="col-md-3 col-sm-6 col-12">
           <div class="card card-product">
             <img class="card-img-top" src="../public/upload/<?php echo e($product->productImage); ?>" alt="Card image cap">
             <div class="card-body">
               <h6 class="card-title product-title mb-3">
                 <a  data-toggle="tooltip" data-placement="bottom" title="
                 <?php echo e($product->productName); ?>"> 
                 <?php echo e($product->productName); ?>

               </a>
                
               </h6>
               <div class="card-text">
                 <span class="new-price"> <?php echo e(number_format($product->listPrice)); ?>đ </span>
                 <span class="old-price text-secondary"> <?php echo e(number_format($product->listPrice)); ?>đ </span>
                 <br>
                 <a class="btn btn-success btn-add-to-cart mt-2" onclick="AddCart(<?php echo e($product->productID); ?>)" href="javascript:"><i class="fas fa-cart-arrow-down"></i></a>
                 <a class="btn btn-outline-success btn-detail mt-2 font-weight-bold" href="<?php echo e(route('detail.show',$product->productID,$product->categoryID)); ?>"> Xem chi tiết</a>
                 <span class="badge badge-danger text-white"><h6><?php echo e($product->discountPercent); ?>%</h6></span>
            
               </div>
               
             </div>
           </div>
            
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </div>
   </div>
  
    <div class="d-flex justify-content-center  mt-5 mb-5"><?php echo e($products->links()); ?></div>
</div>
  <div class="row p-3 gt">
    <div> <?php echo $category->cate_description; ?></div>
    <button type="button" class="btn btn-dark btn-block" >XEM ĐẦY ĐỦ</button>

  </div>
</div>
  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\weblinhkien\resources\views/listproduct.blade.php ENDPATH**/ ?>