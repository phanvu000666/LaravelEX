
<?php $__env->startSection('content'); ?>
<h5 style="font-weight: bold">Thêm chi tiết sản phẩm</h5>
<div class="container">
    <div class="row">
        <div class="col-sm-10">
            <form action="<?php echo e(route('prodetail.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>  
            <div class="form-group">
                <label for="categoryID" style="font-weight: bold">Sản phẩm:</label>
                <select name="productID" id="productID" class="form-control">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->productID); ?>">
                    <?php echo e($product->productName); ?>

                    </option>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
            <div class="form-group">
                <label for="productName" style="font-weight: bold">Tên thương hiệu</label>
                <input type="text" name="brand" id="brand" class="form-control">
            </div>
            <div class="form-group">
                <label for="productName" style="font-weight: bold">Thời gian bảo hành</label>
                <input type="text" name="guarantee" id="guarantee" class="form-control">
            </div>
            <div class="form-group">
                <label for="productImage1" style="font-weight: bold">Chọn hình ảnh thứ nhất :</label>
                <input type="file" name="productImage1" id="productImage1" class="form-control-file"> 
            </div>
            <div class="form-group">
                <label for="productImage1" style="font-weight: bold">Chọn hình ảnh thứ hai :</label>
                <input type="file" name="productImage2" id="productImage2" class="form-control-file"> 
            </div>
            <div class="form-group">
                <label for="productImage1" style="font-weight: bold">Chọn hình ảnh thứ ba :</label>
                <input type="file" name="productImage3" id="productImage3" class="form-control-file"> 
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-info btn-sm" value="lưu thay đổi">
            </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\weblinhkien\resources\views/productdetail/create.blade.php ENDPATH**/ ?>